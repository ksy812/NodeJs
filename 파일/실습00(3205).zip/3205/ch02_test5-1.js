var Calc = require("./calc22");
console.log("김소연의 사칙연산");
console.log("a + b = " + Calc.add(10, 5));
console.log("a - b = " + Calc.sub(10, 5));
console.log("a * b = " + Calc.multiply(10, 5));
console.log("a / b = " + Calc.divide(10, 5));